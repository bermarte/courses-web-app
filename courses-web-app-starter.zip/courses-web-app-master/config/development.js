module.exports = {
  MODE: 'development',
  DATA_DIR: '/data'
};
