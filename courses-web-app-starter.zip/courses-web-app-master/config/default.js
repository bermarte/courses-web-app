module.exports = {
  MODE: 'default',
  PORT: 8080,
  DATA_DIR: '/db'
};
