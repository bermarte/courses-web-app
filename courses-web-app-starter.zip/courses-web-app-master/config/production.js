module.exports = {
  MODE: 'production',
  PORT: process.env.PORT,
  DATA_DIR: process.env.DATA_DIR
};
